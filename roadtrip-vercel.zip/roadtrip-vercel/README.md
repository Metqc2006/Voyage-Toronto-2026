# Notre road trip 2026 🦄

Site statique à page unique — aucune étape de build requise.

## Déployer sur Vercel

**Option A — Glisser-déposer (le plus simple)**
1. Va sur https://vercel.com/new
2. Dézippe ce dossier sur ton ordinateur
3. Glisse le dossier (celui qui contient `index.html`) directement dans la zone d'import de Vercel
4. Clique sur Deploy — c'est tout

**Option B — Import GitHub**
1. Mets ce dossier dans un repo GitHub
2. Sur https://vercel.com/new, choisis "Import Git Repository"
3. Aucune configuration nécessaire (Framework Preset : "Other")
4. Deploy

**Option C — Vercel CLI**
```bash
npm i -g vercel
cd roadtrip-vercel
vercel
```

## Fichiers
- `index.html` — l'application complète (HTML/CSS/JS en un seul fichier), incluant l'onglet ✨ Idées bonus
- `vercel.json` — config minimale (URLs propres, pas de slash final)
